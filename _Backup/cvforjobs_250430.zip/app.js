const express = require("express");
const path = require("path");
const axios = require('axios');
const dotenv = require('dotenv');
const authRoutes = require('./routes/auth');

dotenv.config();
const app = express();

// Set view engine to EJS
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Serve static files from the "public" directory
app.use(express.static(path.join(__dirname, "public")));

//  Handle Form Submission:
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Import routes
const pageRoutes = require("./routes/index");
app.use("/", pageRoutes);

// Registeration
app.use("/api", authRoutes);

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running at http://localhost:${PORT}`);
});
