exports.homePage = (req, res) => {
    res.render("pages/home", { title: "Home" });
};

exports.aboutPage = (req, res) => {
    res.render("pages/about", { title: "About Us" });
};

exports.contactPage = (req, res) => {
    res.render("pages/contact", { title: "Contact Us" });
};
exports.indexPage = (req, res) => {
    res.render("pages/index", { title: "Index Home Page" });
};
exports.joblistPage = (req, res) => {
    res.render("pages/joblist", { title: "Job List" });
};
exports.jobdetailPage = (req, res) => {
    res.render("pages/jobdetail", { title: "Job Details" });
};
exports.jobsearchtipsPage = (req, res) => {
    res.render("pages/jobsearchtips", { title: "Job Search Tips" });
};
exports.jobformPage = (req, res) => {
    res.render("pages/jobform", { title: "Job Search Form" });
};

exports.uaevisaPage = (req, res) => {
    res.render("pages/uae/uaevisa", { title: "UAE Visa Details" });
};
exports.uaejobsitesPage = (req, res) => {
    res.render("pages/uae/uaejobsites", { title: "UAE Job Sites" });
};

