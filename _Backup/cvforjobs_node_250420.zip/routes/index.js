const express = require("express");
const router = express.Router();
const pageController = require("../controllers/pageController");
const jobController = require("../controllers/jobController");
const axios = require('axios');

router.get("/", pageController.homePage);
router.get("/about", pageController.aboutPage);
router.get("/contact", pageController.contactPage);
router.get("/index", pageController.indexPage);
router.get("/jobdetail", pageController.jobdetailPage);
router.get("/joblist", pageController.joblistPage);
router.get("/jobsearchtips", pageController.jobsearchtipsPage);
router.get("/jobform", pageController.jobformPage);

router.get("/uaevisa", pageController.uaevisaPage);
router.get("/uaejobsites", pageController.uaejobsitesPage);

// Jobs via Adzuna
router.get("/jobs", jobController.getJobs);

module.exports = router;
