const express = require('express');
const bcrypt = require('bcrypt');
const pool = require('../db');

const router = express.Router();

router.post('/register', async (req, res) => {
  const {
    email,
    password,
    userType, // 'candidate' or 'employer'
    name,
    fullName,
    contactNumber,
    city,
    country
  } = req.body;

  try {
    // Check if user already exists
    const [existing] = await pool.query('SELECT * FROM Users WHERE Email = ?', [email]);
    if (existing.length > 0) {
      return res.status(409).json({ message: 'Email already registered' });
    }

    // Hash password with bcrypt (salt included)
    const hashedPassword = await bcrypt.hash(password, 10);

    // Insert into Users table
    const [result] = await pool.query(`
      INSERT INTO Users (Email, PasswordHash, UserType)
      VALUES (?, ?, ?)
    `, [email, hashedPassword, userType]);

    const userId = result.insertId;

    // Insert into profile table based on userType
    if (userType === 'candidate') {
      await pool.query(`
        INSERT INTO CandidateProfile
        (CandidateID, Name, FullName, ContactNumber, City, Country)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [userId, name, fullName, contactNumber, city, country]);
    } else if (userType === 'employer') {
      await pool.query(`
        INSERT INTO EmployerProfile
        (EmployerID, ContactPerson, CompanyName, ContactNumber, City, Country)
        VALUES (?, ?, ?, ?, ?, ?)
      `, [userId, name, fullName, contactNumber, city, country]);
    }

    res.status(201).json({ message: 'User registered successfully', userId });

  } catch (error) {
      console.error('Registration error:', error); // Add this for full trace
      res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;
